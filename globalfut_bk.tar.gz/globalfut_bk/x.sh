gcloud compute instances set-machine-type backtest-lu-node1 --zone=us-east4-c --machine-type=n2d-standard-224
gcloud compute instances set-machine-type backtest-lu-node2 --zone=us-east4-c --machine-type=n2d-standard-224
gcloud compute instances set-machine-type backtest-lu-node10 --zone=us-east4-c --machine-type=n2d-standard-224
gcloud compute instances set-machine-type backtest-lu-node3 --zone=us-east4-c --machine-type=n2d-standard-224
