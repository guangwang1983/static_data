#!/bin/sh
mkdir globalfx_bk
cp GLOBAL_LIVE_PRODUCTION_PORTFOLIO/arguments.dat`globalfx_bk/
cp *def globalfx_bk/
cp *.sh globalfx_bk/
