#!/bin/sh
stop_nodes10.sh
upgrade_machines10-128.sh
start_nodes5.sh

checkNodesReady5.sh

cd $PRODUCTIONPATH/library/lib_launch_dir_full
tail -n 2 $STATICDATAPATH/datesfiles/DYNAMIC_DATESFILE_SIMDATES > weekly_dates.dat
#cat $STATICDATAPATH/datesfiles/DYNAMIC_DATESFILE_SIMDATES | grep ^2023 > dates2023.dat

full_library_simulation_manager.py --sublibfile /dat/matterhorn/data/static_data/sublibrary_usdcad.dat --datesfile /dat/matterhorn/production/library/lib_launch_dir_full/weekly_dates.dat --restart Clean --simulationtype all_update --fivenodes True

dbcheck-and-kill-instance.sh 10
sleep 1200
