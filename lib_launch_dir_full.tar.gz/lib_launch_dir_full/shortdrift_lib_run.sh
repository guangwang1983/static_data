#!/bin/sh

cd $PRODUCTIONPATH/library/lib_launch_dir_full
#cat $STATICDATAPATH/datesfiles/DYNAMIC_DATESFILE_SIMDATES | grep ^2023 > dates2023.dat

#full_library_simulation_manager.py --sublibfile /dat/matterhorn/production/library/lib_launch_dir_full/sublibrary_fxfi.dat --datesfile /dat/matterhorn/production/library/lib_launch_dir_full/weekly_dates.dat --restart Clean --simulationtype all --appendintrares False

full_library_simulation_manager_ONP.py --sublibfile /dat/matterhorn/production/library/lib_launch_dir_full/sublibrary_ONP.dat --datesfile /dat/matterhorn/production/library/lib_launch_dir_full/weekly_dates.dat --restart Clean --simulationtype all --appendintrares False  --fivenodes True
#full_library_simulation_manager.py --sublibfile /dat/matterhorn/production/library/lib_launch_dir_full/sublibrarylist_full.dat --datesfile /dat/matterhorn/production/library/lib_launch_dir_full/weekly_dates.dat --restart Clean --simulationtype intra --syncdata False

dbcheck-and-kill-instance.sh 10
