#!/bin/sh
stop_nodes10.sh
upgrade_machines10-128.sh
start_nodes10.sh

checkNodesReady.sh

cd $PRODUCTIONPATH/library/lib_launch_dir_full
#tail -n 5 $STATICDATAPATH/datesfiles/DYNAMIC_DATESFILE_SIMDATES > weekly_dates.dat
#cat $STATICDATAPATH/datesfiles/DYNAMIC_DATESFILE_SIMDATES | grep ^2023 > dates2023.dat

full_library_simulation_manager.py --sublibfile /dat/matterhorn/production/library/lib_launch_dir_full/sublibrarylist_full.dat --datesfile /dat/matterhorn/production/library/lib_launch_dir_full/weekly_dates.dat --restart Clean --simulationtype all_update --dynamic True

#full_library_simulation_manager.py --sublibfile /dat/matterhorn/production/library/lib_launch_dir_full/sublibrarylist_full.dat --datesfile /dat/matterhorn/production/library/lib_launch_dir_full/weekly_dates.dat --restart Clean --simulationtype intra --syncdata False

dbcheck-and-kill-instance.sh 10
sleep 1200
