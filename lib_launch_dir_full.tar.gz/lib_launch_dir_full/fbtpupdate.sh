#!/bin/sh
#start_nodes5.sh
#checkNodesReady5.sh

cd $PRODUCTIONPATH/library/lib_launch_dir_full
tail -n 6 $STATICDATAPATH/datesfiles/DYNAMIC_DATESFILE_SIMDATES > weekly_dates6.dat
#cat $STATICDATAPATH/datesfiles/DYNAMIC_DATESFILE_SIMDATES | grep ^2023 > dates2023.dat

full_library_simulation_manager.py --sublibfile /dat/matterhorn/production/library/lib_launch_dir_full/sublibrary_fbtp.dat --datesfile /dat/matterhorn/production/library/lib_launch_dir_full/weekly_dates6.dat --restart Clean --simulationtype all_update --fivenodes True

