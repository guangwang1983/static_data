#!/bin/sh
upgrade_machines10-128.sh
start_nodes5.sh
checkNodesReady5.sh
#start_nodes10.sh
#checkNodesReady.sh
cd $PRODUCTIONPATH/library/lib_launch_dir_full
cp dates201620231231.dat weekly_dates.dat
#tail -n 1785 $STATICDATAPATH/datesfiles/DYNAMIC_DATESFILE_SIMDATES > weekly_dates.dat
#tail -n 2 $STATICDATAPATH/datesfiles/DYNAMIC_DATESFILE_SIMDATES > weekly_dates.dat

#full_library_simulation_manager.py --sublibfile /dat/matterhorn/production/library/lib_launch_dir_full/tls2.dat --datesfile /dat/matterhorn/production/library/lib_launch_dir_full/weekly_dates.dat --restart Clean --simulationtype all --appendintrares False --fivenodes True --dynamic True 
#full_library_simulation_manager_TLS.py --sublibfile /dat/matterhorn/production/library/lib_launch_dir_full/tls.dat --datesfile /dat/matterhorn/production/library/lib_launch_dir_full/weekly_dates.dat --restart Clean --simulationtype all --appendintrares False --dynamic True --numnodes 4
#full_library_simulation_manager.py --sublibfile /dat/matterhorn/production/library/lib_launch_dir_full/sublibrarylist_full.dat --datesfile /dat/matterhorn/production/library/lib_launch_dir_full/weekly_dates.dat --restart Clean --simulationtype intra --syncdata False

full_library_simulation_manager.py --sublibfile /dat/matterhorn/production/library/lib_launch_dir_full/tls2.dat --datesfile /dat/matterhorn/production/library/lib_launch_dir_full/weekly_dates.dat --restart Clean --simulationtype txintra --appendintrares False --fivenodes True 


dbcheck-and-kill-instance.sh 10
