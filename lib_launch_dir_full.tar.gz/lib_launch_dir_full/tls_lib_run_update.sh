#!/bin/sh
#upgrade_machines10-128.sh
start_nodes4.sh
checkNodesReady4.sh
#upgrade_machines10-128.sh
#start_nodes10.sh
#checkNodesReady.sh
cd $PRODUCTIONPATH/library/lib_launch_dir_full
tail -n 5 $STATICDATAPATH/datesfiles/DYNAMIC_DATESFILE_SIMDATES > weekly_dates.dat

#full_library_simulation_manager.py --sublibfile /dat/matterhorn/production/library/lib_launch_dir_full/sublibrary_fxfi.dat --datesfile /dat/matterhorn/production/library/lib_launch_dir_full/weekly_dates.dat --restart Clean --simulationtype all --appendintrares False
full_library_simulation_manager_TLS.py --sublibfile /dat/matterhorn/production/library/lib_launch_dir_full/tls2.dat --datesfile /dat/matterhorn/production/library/lib_launch_dir_full/weekly_dates.dat --restart Clean --simulationtype intra --numnodes 4
#full_library_simulation_manager.py --sublibfile /dat/matterhorn/production/library/lib_launch_dir_full/sublibrarylist_full.dat --datesfile /dat/matterhorn/production/library/lib_launch_dir_full/weekly_dates.dat --restart Clean --simulationtype intra --syncdata False

dbcheck-and-kill-instance.sh 10
